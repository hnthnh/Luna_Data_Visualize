
import DaihatsuApp_ver2 as appV2

if __name__ == "__main__":
    #app.DaihatsuApp().mainloop()
    appV2.DaihatsuApp_ver2().mainloop()
        
        